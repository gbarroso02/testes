import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { format } from "date-fns";
import { 
  CalendarIcon, 
  Search, 
  FileText, 
  MapPin, 
  CheckCircle, 
  ArrowRight, 
  Trash2,
  X
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { insertAppointmentSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

const examCategories = [
  { id: "imagem", name: "Exames de Imagem", count: 23 },
  { id: "laboratoriais", name: "Exames Laboratoriais", count: 45 },
  { id: "cardiologicos", name: "Exames Cardiológicos", count: 18 },
  { id: "gastro", name: "Exames Gastroenterológicos", count: 12 },
  { id: "neurologicos", name: "Exames Neurológicos", count: 15 },
];

const popularExams = [
  "Hemograma Completo",
  "Ressonância Magnética",
  "Eletrocardiograma",
  "Tomografia Computadorizada",
  "Ultrassonografia",
  "Endoscopia",
  "Mamografia",
  "Raio-X"
];

const locations = [
  {
    name: "Centro Médico São Paulo",
    address: "Av. Paulista, 1000, São Paulo - SP",
    distance: "2.5 km",
    available: true
  },
  {
    name: "Centro Diagnóstico MediCare",
    address: "Rua Augusta, 500, São Paulo - SP",
    distance: "3.2 km",
    available: true
  },
  {
    name: "Laboratório Central",
    address: "Av. Rebouças, 850, São Paulo - SP",
    distance: "4.1 km",
    available: true
  }
];

// Schema for exams
const ExamScheduleSchema = insertAppointmentSchema.extend({
  examType: z.string().min(1, "Selecione um tipo de exame"),
  location: z.string().min(1, "Selecione uma unidade"),
  preferredDate: z.date(),
  termsAccepted: z.boolean().refine(val => val === true, {
    message: "Você precisa aceitar os termos para continuar.",
  }),
});

// Enum para as etapas do agendamento
enum SchedulingStep {
  SelectExams,
  SelectDate,
  SelectLocation,
  UserRegistration
}

// Tipo para o exame selecionado
type SelectedExam = {
  name: string;
  date?: Date;
};

export default function ExamSchedule() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredExams, setFilteredExams] = useState<string[]>([]);
  
  // Estado para controlar as etapas do agendamento
  const [currentStep, setCurrentStep] = useState<SchedulingStep>(SchedulingStep.SelectExams);
  
  // Lista de exames selecionados
  const [selectedExams, setSelectedExams] = useState<SelectedExam[]>([]);
  
  // Data selecionada para todos os exames
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  
  // Local selecionado
  const [selectedLocation, setSelectedLocation] = useState<string>("");

  const form = useForm<z.infer<typeof ExamScheduleSchema>>({
    resolver: zodResolver(ExamScheduleSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      specialty: "",
      examType: "",
      location: "",
      preferredDate: new Date(),
      message: "",
      termsAccepted: false,
    },
  });

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    if (value.length > 1) {
      const filtered = popularExams.filter(exam => 
        exam.toLowerCase().includes(value.toLowerCase())
      );
      setFilteredExams(filtered);
    } else {
      setFilteredExams([]);
    }
  };

  const addExam = (exam: string) => {
    // Verifica se o exame já foi selecionado
    if (!selectedExams.some(e => e.name === exam)) {
      setSelectedExams([...selectedExams, { name: exam }]);
    }
    
    setFilteredExams([]);
    setSearchTerm("");
  };
  
  const removeExam = (exam: string) => {
    setSelectedExams(selectedExams.filter(e => e.name !== exam));
  };
  
  const goToNextStep = () => {
    if (currentStep === SchedulingStep.SelectExams && selectedExams.length > 0) {
      setCurrentStep(SchedulingStep.SelectDate);
    } else if (currentStep === SchedulingStep.SelectDate) {
      setCurrentStep(SchedulingStep.SelectLocation);
    } else if (currentStep === SchedulingStep.SelectLocation && selectedLocation) {
      setCurrentStep(SchedulingStep.UserRegistration);
    }
  };
  
  const goToPreviousStep = () => {
    if (currentStep === SchedulingStep.SelectDate) {
      setCurrentStep(SchedulingStep.SelectExams);
    } else if (currentStep === SchedulingStep.SelectLocation) {
      setCurrentStep(SchedulingStep.SelectDate);
    } else if (currentStep === SchedulingStep.UserRegistration) {
      setCurrentStep(SchedulingStep.SelectLocation);
    }
  };

  const examMutation = useMutation({
    mutationFn: async (data: z.infer<typeof insertAppointmentSchema>) => {
      return await apiRequest("POST", "/api/appointments", data);
    },
    onSuccess: () => {
      toast({
        title: "Solicitação enviada",
        description: "Sua solicitação de agendamento de exame foi enviada com sucesso. Entraremos em contato em breve.",
        variant: "default",
      });
      form.reset();
      setIsSubmitting(false);
      setSelectedExams([]);
      setSearchTerm("");
      setCurrentStep(SchedulingStep.SelectExams);
    },
    onError: (error) => {
      toast({
        title: "Erro ao enviar solicitação",
        description: error.message || "Ocorreu um erro ao enviar sua solicitação. Por favor, tente novamente.",
        variant: "destructive",
      });
      setIsSubmitting(false);
    },
  });

  function onSubmit(data: z.infer<typeof ExamScheduleSchema>) {
    setIsSubmitting(true);
    
    if (selectedExams.length === 0) {
      toast({
        title: "Erro ao enviar solicitação",
        description: "Por favor, selecione pelo menos um exame para agendar.",
        variant: "destructive",
      });
      setIsSubmitting(false);
      return;
    }
    
    // Remove the fields that aren't in our DB schema
    const { termsAccepted, examType, location, preferredDate, ...appointmentData } = data;
    
    // Criar string com todos os exames selecionados e local
    const examesStr = selectedExams.map(e => e.name).join(", ");
    
    // Use the data from our state instead of form fields
    const examData = {
      ...appointmentData,
      specialty: `Exames: ${examesStr} - Local: ${selectedLocation}`,
      preferredDate: format(selectedDate, 'yyyy-MM-dd'),
    };
    
    // Enviar requisição para o backend
    examMutation.mutate(examData);
  }

  // Renderiza a lista de exames selecionados
  const renderSelectedExams = () => {
    if (selectedExams.length === 0) return null;
    
    return (
      <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
        <h3 className="text-lg font-semibold mb-3">Exames Selecionados</h3>
        <div className="flex flex-wrap gap-2">
          {selectedExams.map((exam, index) => (
            <Badge 
              key={index} 
              variant="secondary"
              className="py-2 px-3 text-sm flex items-center gap-2"
            >
              <span>{exam.name}</span>
              <button 
                type="button" 
                onClick={() => removeExam(exam.name)}
                className="hover:bg-gray-200 p-1 rounded-full"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
        </div>
      </div>
    );
  };

  // Renderiza os passos de navegação
  const renderStepIndicator = () => {
    return (
      <div className="mb-8">
        <div className="flex justify-between items-center">
          {[
            { step: SchedulingStep.SelectExams, label: "Selecionar Exames" },
            { step: SchedulingStep.SelectDate, label: "Selecionar Data" },
            { step: SchedulingStep.SelectLocation, label: "Selecionar Local" },
            { step: SchedulingStep.UserRegistration, label: "Cadastro" }
          ].map((item, index) => (
            <div key={index} className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= item.step ? 'bg-primary text-white' : 'bg-gray-200 text-gray-600'}`}>
                {index + 1}
              </div>
              <span className="text-xs mt-1">{item.label}</span>
            </div>
          ))}
        </div>
        <div className="relative mt-2">
          <div className="absolute h-1 bg-gray-200 top-0 left-0 right-0"></div>
          <div 
            className="absolute h-1 bg-primary top-0 left-0" 
            style={{ width: `${(currentStep / 3) * 100}%` }} 
          ></div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4 py-12">
        <div className="mb-10 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Agendar Exames</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">Agende seus exames com facilidade e rapidez em uma de nossas unidades.</p>
          
          {renderStepIndicator()}
          
          {/* Step 1: Select Exams */}
          {currentStep === SchedulingStep.SelectExams && (
            <>
              {renderSelectedExams()}
              
              {/* Search Bar */}
              <div className="max-w-2xl mx-auto mb-10">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Search className="text-gray-400" />
                  </div>
                  <Input
                    type="text"
                    placeholder="Buscar exame (ex: Hemograma, Raio-X, etc.)"
                    className="pl-10 py-6 text-lg"
                    value={searchTerm}
                    onChange={(e) => handleSearch(e.target.value)}
                  />
                  {filteredExams.length > 0 && (
                    <div className="absolute w-full bg-white mt-1 rounded-md shadow-lg z-10 border">
                      <ul className="py-1">
                        {filteredExams.map((exam, index) => (
                          <li 
                            key={index} 
                            className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                            onClick={() => addExam(exam)}
                          >
                            <div className="flex items-center">
                              <FileText className="mr-2 h-5 w-5 text-primary" />
                              {exam}
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
          
          {/* Step 2: Select Date */}
          {currentStep === SchedulingStep.SelectDate && (
            <div className="max-w-4xl mx-auto">
              <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
                <h3 className="text-xl font-bold mb-4">Selecione uma Data</h3>
                <div className="mb-6">
                  <p className="text-gray-600 mb-4">Para os exames selecionados:</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {selectedExams.map((exam, index) => (
                      <Badge key={index} variant="outline" className="py-1.5 px-3">
                        {exam.name}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="max-w-md mx-auto">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => date && setSelectedDate(date)}
                    className="rounded-md border shadow"
                    disabled={(date) => date < new Date()}
                  />
                </div>
                
                <div className="mt-6 flex justify-between">
                  <Button variant="outline" onClick={goToPreviousStep}>
                    Voltar
                  </Button>
                  <Button 
                    onClick={goToNextStep}
                    disabled={!selectedDate}
                  >
                    Continuar <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 3: Select Location */}
          {currentStep === SchedulingStep.SelectLocation && (
            <div className="max-w-4xl mx-auto">
              <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
                <h3 className="text-xl font-bold mb-4">Selecione uma Unidade</h3>
                <div className="mb-6">
                  <p className="text-gray-600 mb-2">Para os exames selecionados na data:</p>
                  <p className="font-semibold text-lg mb-4">{format(selectedDate, "dd/MM/yyyy")}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {selectedExams.map((exam, index) => (
                      <Badge key={index} variant="outline" className="py-1.5 px-3">
                        {exam.name}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-4">
                  {locations.map((location, index) => (
                    <Card 
                      key={index} 
                      className={`cursor-pointer transition-all ${selectedLocation === location.name ? 'ring-2 ring-primary' : 'hover:shadow-md'}`}
                      onClick={() => setSelectedLocation(location.name)}
                    >
                      <CardContent className="p-4 flex items-start">
                        <div className="bg-primary/10 p-3 rounded-full mr-4">
                          <MapPin className="text-primary" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-bold">{location.name}</h3>
                          <p className="text-gray-600 text-sm">{location.address}</p>
                          <div className="flex items-center mt-2">
                            <span className="text-sm text-gray-500 mr-3">{location.distance}</span>
                            {location.available ? (
                              <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Disponível</span>
                            ) : (
                              <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full">Indisponível</span>
                            )}
                          </div>
                        </div>
                        {selectedLocation === location.name && (
                          <div className="text-primary">
                            <CheckCircle className="h-6 w-6" />
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
                
                <div className="mt-6 flex justify-between">
                  <Button variant="outline" onClick={goToPreviousStep}>
                    Voltar
                  </Button>
                  <Button 
                    onClick={goToNextStep}
                    disabled={!selectedLocation}
                  >
                    Continuar <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 4: User Registration */}
          {currentStep === SchedulingStep.UserRegistration && (
            <div className="max-w-4xl mx-auto">
              <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
                <h3 className="text-xl font-bold mb-4">Complete seu Cadastro</h3>
                <div className="mb-6">
                  <p className="text-gray-600 mb-2">Resumo do agendamento:</p>
                  <div className="bg-gray-50 p-4 rounded-md mb-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">Exames:</p>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {selectedExams.map((exam, index) => (
                            <Badge key={index} variant="outline" className="py-1 px-2">
                              {exam.name}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Data:</p>
                        <p className="font-medium">{format(selectedDate, "dd/MM/yyyy")}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Local:</p>
                        <p className="font-medium">{selectedLocation}</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-800">Nome Completo</FormLabel>
                            <FormControl>
                              <Input placeholder="Digite seu nome" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-800">E-mail</FormLabel>
                            <FormControl>
                              <Input placeholder="Digite seu e-mail" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-800">Telefone</FormLabel>
                          <FormControl>
                            <Input placeholder="(00) 00000-0000" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-800">Observações (opcional)</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Alguma informação adicional?"
                              value={field.value || ""}
                              onChange={field.onChange}
                              onBlur={field.onBlur}
                              ref={field.ref}
                              name={field.name}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="termsAccepted"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel className="text-sm text-gray-600">
                              Concordo com os <a href="#" className="text-primary hover:underline">termos de uso</a> e <a href="#" className="text-primary hover:underline">política de privacidade</a>.
                            </FormLabel>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-between">
                      <Button type="button" variant="outline" onClick={goToPreviousStep}>
                        Voltar
                      </Button>
                      <Button 
                        type="submit" 
                        className=""
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? "Enviando..." : "Confirmar Agendamento"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            </div>
          )}
          
          {/* Step 1: Categories and Popular Exams (Shown only in the first step) */}
          {currentStep === SchedulingStep.SelectExams && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Categories */}
              <div>
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h2 className="text-xl font-bold mb-4">Categorias de Exames</h2>
                  <ul className="space-y-3">
                    {examCategories.map((category) => (
                      <li key={category.id}>
                        <button
                          className="w-full text-left p-3 hover:bg-gray-50 rounded-md transition-colors flex justify-between items-center"
                          onClick={() => {}}
                        >
                          <span>{category.name}</span>
                          <span className="bg-gray-100 text-gray-600 text-sm px-2 py-1 rounded-full">
                            {category.count}
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-sm mt-6">
                  <h2 className="text-xl font-bold mb-4">Exames Populares</h2>
                  <div className="flex flex-wrap gap-2">
                    {popularExams.slice(0, 6).map((exam, index) => (
                      <button
                        key={index}
                        className="bg-gray-100 hover:bg-gray-200 text-gray-800 px-3 py-1 rounded-full text-sm"
                        onClick={() => addExam(exam)}
                      >
                        {exam}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Selected Exams Summary */}
              <div className="lg:col-span-2">
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h2 className="text-xl font-bold mb-6">Exames Selecionados</h2>
                  
                  {selectedExams.length === 0 ? (
                    <div className="text-center py-12 border-2 border-dashed border-gray-200 rounded-lg">
                      <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-500 mb-4">Nenhum exame selecionado ainda</p>
                      <p className="text-gray-400 text-sm max-w-md mx-auto">
                        Use a barra de busca acima ou navegue pelas categorias para adicionar exames à sua lista
                      </p>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-4 mb-6">
                        {selectedExams.map((exam, index) => (
                          <div key={index} className="flex justify-between items-center p-3 border rounded-lg bg-gray-50">
                            <div className="flex items-center">
                              <FileText className="mr-3 h-5 w-5 text-primary" />
                              <span>{exam.name}</span>
                            </div>
                            <button 
                              type="button" 
                              onClick={() => removeExam(exam.name)}
                              className="text-gray-400 hover:text-red-500"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                      
                      <Button 
                        onClick={goToNextStep} 
                        className="w-full"
                      >
                        Continuar <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}