import { Facebook, Instagram, Linkedin, Twitter, MapPin, Mail, Phone, Clock } from "lucide-react";
import { Link } from "wouter";
import medlabLogo from "@assets/278965285_103604832341418_2879733212450487249_n.png";

export default function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <footer className="bg-gray-800 text-gray-300 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="mb-6">
              <Link href="/">
                <img src={medlabLogo} alt="MedLab" className="h-12 bg-white p-1 rounded" />
              </Link>
            </div>
            <p className="mb-6">Resultados precisos para cuidar da sua saúde com excelência e tecnologia avançada.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white text-lg font-bold mb-6">Links Rápidos</h3>
            <ul className="space-y-3">
              <li>
                <button 
                  onClick={() => scrollToSection('inicio')} 
                  className="hover:text-red-400 transition-colors flex items-center"
                >
                  <span className="mr-2">›</span> Início
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('especialidades')} 
                  className="hover:text-red-400 transition-colors flex items-center"
                >
                  <span className="mr-2">›</span> Exames
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('medicos')} 
                  className="hover:text-red-400 transition-colors flex items-center"
                >
                  <span className="mr-2">›</span> Especialistas
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('sobre')} 
                  className="hover:text-red-400 transition-colors flex items-center"
                >
                  <span className="mr-2">›</span> Sobre Nós
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('contato')} 
                  className="hover:text-red-400 transition-colors flex items-center"
                >
                  <span className="mr-2">›</span> Contato
                </button>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white text-lg font-bold mb-6">Nossos Exames</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/agendar/exames" className="hover:text-red-400 transition-colors flex items-center">
                  <span className="mr-2">›</span> Exames de Sangue
                </Link>
              </li>
              <li>
                <Link href="/agendar/exames" className="hover:text-red-400 transition-colors flex items-center">
                  <span className="mr-2">›</span> Exames Genéticos
                </Link>
              </li>
              <li>
                <Link href="/agendar/exames" className="hover:text-red-400 transition-colors flex items-center">
                  <span className="mr-2">›</span> Exames de Imagem
                </Link>
              </li>
              <li>
                <Link href="/agendar/exames" className="hover:text-red-400 transition-colors flex items-center">
                  <span className="mr-2">›</span> Bioquímica Clínica
                </Link>
              </li>
              <li>
                <Link href="/agendar/exames" className="hover:text-red-400 transition-colors flex items-center">
                  <span className="mr-2">›</span> Check-up Completo
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white text-lg font-bold mb-6">Contato</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="mr-3 h-5 w-5 text-red-400 shrink-0 mt-0.5" />
                <span>Av. Paulista, 1000 - Bela Vista São Paulo - SP, 01310-100</span>
              </li>
              <li className="flex items-center">
                <Phone className="mr-3 h-5 w-5 text-red-400 shrink-0" />
                <span>(11) 3456-7890</span>
              </li>
              <li className="flex items-center">
                <Mail className="mr-3 h-5 w-5 text-red-400 shrink-0" />
                <span>contato@medlab.com.br</span>
              </li>
              <li className="flex items-start">
                <Clock className="mr-3 h-5 w-5 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <p>Seg - Sex: 07:00 - 19:00</p>
                  <p>Sábados: 07:00 - 13:00</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p>&copy; {new Date().getFullYear()} MedLab - Exames Médicos Laboratoriais Ltda. Todos os direitos reservados.</p>
            <div className="mt-4 md:mt-0">
              <a href="#" className="text-sm text-gray-400 hover:text-red-400 mr-6 transition-colors">
                Política de Privacidade
              </a>
              <a href="#" className="text-sm text-gray-400 hover:text-red-400 transition-colors">
                Termos de Uso
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
