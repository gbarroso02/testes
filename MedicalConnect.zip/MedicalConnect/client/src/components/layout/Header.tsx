import { useState } from "react";
import { Menu, X, TestTube, Home, Stethoscope, Users, Info, Mail, UserCircle, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";

// Importar a logo da MedLab
import medlabLogo from "@assets/278965285_103604832341418_2879733212450487249_n.png";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const scrollToSection = (id: string) => {
    closeMobileMenu();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <header className="sticky top-0 bg-white shadow-md z-50">
      <div className="container mx-auto px-4 py-2">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <img src={medlabLogo} alt="MedLab" className="h-12 mr-2" />
            </Link>
          </div>
          
          {/* Desktop Menu */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="flex items-center text-gray-700 hover:text-medlab-red font-medium transition-colors">
              <Home size={18} className="mr-1" />
              <span>Início</span>
            </Link>
            <button onClick={() => scrollToSection('especialidades')} className="flex items-center text-gray-700 hover:text-medlab-red font-medium transition-colors">
              <TestTube size={18} className="mr-1" />
              <span>Exames</span>
            </button>
            <button onClick={() => scrollToSection('medicos')} className="flex items-center text-gray-700 hover:text-medlab-red font-medium transition-colors">
              <Stethoscope size={18} className="mr-1" />
              <span>Especialistas</span>
            </button>
            <button onClick={() => scrollToSection('sobre')} className="flex items-center text-gray-700 hover:text-medlab-red font-medium transition-colors">
              <Info size={18} className="mr-1" />
              <span>Sobre</span>
            </button>
            <button onClick={() => scrollToSection('contato')} className="flex items-center text-gray-700 hover:text-medlab-red font-medium transition-colors">
              <Mail size={18} className="mr-1" />
              <span>Contato</span>
            </button>
            <Link href="/agendar/exames">
              <Button className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 shadow-md">
                Agendar Exame
              </Button>
            </Link>
          </nav>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button onClick={toggleMobileMenu} className="text-gray-800 hover:text-medlab-red transition-colors">
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="flex items-center text-gray-700 hover:text-medlab-red font-medium transition-colors">
                <Home size={18} className="mr-2" />
                <span>Início</span>
              </Link>
              <button onClick={() => scrollToSection('especialidades')} className="flex items-center text-gray-700 hover:text-medlab-red font-medium transition-colors">
                <TestTube size={18} className="mr-2" />
                <span>Exames</span>
              </button>
              <button onClick={() => scrollToSection('medicos')} className="flex items-center text-gray-700 hover:text-medlab-red font-medium transition-colors">
                <Stethoscope size={18} className="mr-2" />
                <span>Especialistas</span>
              </button>
              <button onClick={() => scrollToSection('sobre')} className="flex items-center text-gray-700 hover:text-medlab-red font-medium transition-colors">
                <Info size={18} className="mr-2" />
                <span>Sobre</span>
              </button>
              <button onClick={() => scrollToSection('contato')} className="flex items-center text-gray-700 hover:text-medlab-red font-medium transition-colors">
                <Mail size={18} className="mr-2" />
                <span>Contato</span>
              </button>
              <Link href="/agendar/exames">
                <Button className="w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 shadow-md">
                  Agendar Exame
                </Button>
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
