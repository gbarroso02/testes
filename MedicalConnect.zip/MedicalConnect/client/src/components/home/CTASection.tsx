import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function CTASection() {
  return (
    <section className="py-16 bg-blue-400 text-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-2/3 mb-8 md:mb-0">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Cuidados médicos online e presenciais</h2>
            <p className="text-xl">Consulte-se com os melhores especialistas sem sair de casa ou agende seus exames em uma de nossas unidades.</p>
          </div>
          <div>
            <Link href="/agendar/exames">
              <Button 
                variant="outline" 
                size="lg"
                className="bg-white text-primary hover:bg-white/90"
              >
                Agendar Exames
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
