import { 
  TestTube, 
  Dna, 
  Microscope, 
  HeartPulse, 
  Baby, 
  FlaskConical, 
  ChevronRight
} from "lucide-react";
import { Link } from "wouter";

export default function ServicesSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const services = [
    {
      icon: <TestTube className="text-medlab-red text-2xl" />,
      title: "Exames de Sangue",
      description: "Análises completas de hemograma, glicemia, colesterol, triglicerídeos e mais."
    },
    {
      icon: <Dna className="text-medlab-red text-2xl" />,
      title: "Exames Genéticos",
      description: "Testes genéticos avançados para detecção de predisposições e doenças hereditárias."
    },
    {
      icon: <Microscope className="text-medlab-red text-2xl" />,
      title: "Análises Clínicas",
      description: "Laboratório moderno para análises clínicas diversas com resultados precisos."
    },
    {
      icon: <HeartPulse className="text-medlab-red text-2xl" />,
      title: "Cardiológicos",
      description: "Exames específicos para avaliação da saúde cardiovascular e prevenção de doenças."
    },
    {
      icon: <Baby className="text-medlab-red text-2xl" />,
      title: "Exames Pré-natais",
      description: "Acompanhamento completo de gestantes com exames específicos para cada fase."
    },
    {
      icon: <FlaskConical className="text-medlab-red text-2xl" />,
      title: "Microbiologia",
      description: "Análises microbiológicas para identificação de patógenos e testes de sensibilidade."
    }
  ];

  return (
    <section id="especialidades" className="py-16 bg-gray-50 relative overflow-hidden">
      {/* Elemento decorativo */}
      <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-24 h-[500px] bg-medlab-yellow opacity-20 rounded-r-full"></div>
      
      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1 bg-red-50 rounded-full text-medlab-red text-sm font-medium mb-4">NOSSOS SERVIÇOS</span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Exames Laboratoriais</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Resultados precisos e confiáveis para auxiliar no diagnóstico e prevenção de doenças, 
            usando tecnologia de ponta e profissionais qualificados.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="bg-white rounded-lg border border-gray-100 p-6 shadow-sm hover:shadow-md transition duration-300 group"
            >
              <div className="w-14 h-14 bg-red-50 rounded-lg flex items-center justify-center mb-6 transform group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-800">{service.title}</h3>
              <p className="text-gray-600 mb-6">{service.description}</p>
              <Link href="/agendar/exames" className="w-full">
                <button 
                  className="text-medlab-red font-medium hover:underline inline-flex items-center"
                >
                  Agendar exame <ChevronRight className="ml-2 h-4 w-4" />
                </button>
              </Link>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <Link href="/agendar/exames">
            <button className="bg-white text-medlab-red font-medium px-8 py-3 rounded-full inline-flex items-center border-2 border-red-100 shadow-sm hover:shadow-md transition-all">
              Ver todos os exames <ChevronRight className="ml-2 h-4 w-4" />
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
}
