import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { TestTube, Microscope, Activity, CheckCircle } from "lucide-react";

export default function HeroSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section id="inicio" className="relative overflow-hidden py-16 md:py-24">
      {/* Fundo com círculo amarelo estilizado (inspirado na logo) */}
      <div className="absolute -right-48 -top-48 w-96 h-96 rounded-full bg-medlab-yellow opacity-60"></div>
      <div className="absolute -left-24 bottom-0 w-64 h-64 rounded-full bg-medlab-yellow opacity-30"></div>
      
      <div className="container mx-auto px-4 relative">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 md:pr-12 mb-8 md:mb-0">
            <div className="inline-block px-4 py-2 bg-red-50 rounded-full text-medlab-red mb-4 font-medium">
              MedLab - Excelência em Exames Laboratoriais
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-gray-800">Sua saúde em <span className="text-medlab-red">primeiro</span> lugar</h1>
            <p className="text-xl mb-8 text-gray-600">Resultados precisos e atendimento humanizado. Conheça nossos exames e agende sua visita.</p>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="flex items-start">
                <div className="bg-red-50 p-2 rounded-full mr-3">
                  <TestTube className="h-5 w-5 text-medlab-red" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">Exames completos</h3>
                  <p className="text-sm text-gray-600">Ampla gama de exames laboratoriais</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-red-50 p-2 rounded-full mr-3">
                  <Microscope className="h-5 w-5 text-medlab-red" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">Alta precisão</h3>
                  <p className="text-sm text-gray-600">Tecnologia moderna e confiável</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-red-50 p-2 rounded-full mr-3">
                  <Activity className="h-5 w-5 text-medlab-red" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">Resultados rápidos</h3>
                  <p className="text-sm text-gray-600">Entrega ágil dos resultados</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-red-50 p-2 rounded-full mr-3">
                  <CheckCircle className="h-5 w-5 text-medlab-red" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">Qualidade</h3>
                  <p className="text-sm text-gray-600">Processos certificados</p>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/agendar/exames">
                <Button className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 shadow-md">
                  Agendar Exames
                </Button>
              </Link>
              <Button 
                onClick={() => scrollToSection('especialidades')}
                variant="outline" 
                className="border-2 border-gray-300 text-gray-800 hover:bg-gray-50"
              >
                Conhecer Serviços
              </Button>
            </div>
          </div>
          <div className="md:w-1/2 relative">
            <div className="absolute -left-4 -top-4 w-full h-full bg-yellow-300 rounded-lg opacity-30 transform rotate-3"></div>
            <img 
              src="https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
              alt="Laboratório moderno" 
              className="rounded-lg shadow-lg w-full relative z-10 transform -rotate-2"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
