import { useState } from "react";
import { ChevronDown, ChevronRight, HelpCircle, MessagesSquare } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";

export default function FAQSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const faqs = [
    {
      question: "É necessário jejum para todos os exames?",
      answer: "Não, nem todos os exames exigem jejum. Exames como hemograma, colesterol, glicemia e triglicerídeos geralmente requerem jejum de 8 a 12 horas. Já outros como tipagem sanguínea, HIV, exames de imagem (raio-X, ultrassom) e urina não exigem preparo específico. As orientações de preparo são enviadas por e-mail após o agendamento e também podem ser consultadas em nosso site."
    },
    {
      question: "Quais convênios são aceitos pela MedLab?",
      answer: "A MedLab aceita os principais convênios de saúde, incluindo Unimed, Amil, Bradesco Saúde, SulAmérica, Porto Seguro, entre outros. Para verificar se seu convênio está na lista de parceiros, entre em contato com nosso atendimento por telefone ou e-mail."
    },
    {
      question: "Quanto tempo leva para receber os resultados dos exames?",
      answer: "O prazo varia conforme o tipo de exame. Exames de rotina como hemograma e colesterol estão disponíveis em até 24 horas. Exames hormonais e bioquímicos em até 48 horas. Exames mais complexos como genéticos e histopatológicos podem levar de 7 a 15 dias. Todos os resultados são disponibilizados em nossa plataforma online, com acesso seguro pelo paciente."
    },
    {
      question: "Como faço para reagendar ou cancelar meu exame?",
      answer: "Para reagendar ou cancelar um exame, você pode acessar nossa plataforma online com seu login e senha, utilizar nosso aplicativo, ou entrar em contato com nossa central de atendimento. Solicitamos que alterações sejam feitas com pelo menos 24 horas de antecedência para evitar cobranças e permitir que outros pacientes possam utilizar o horário."
    },
    {
      question: "Posso realizar exames em domicílio?",
      answer: "Sim, oferecemos serviço de coleta domiciliar para diversos exames laboratoriais, especialmente para idosos, pessoas com mobilidade reduzida ou que precisam de maior comodidade. A coleta domiciliar deve ser agendada com pelo menos 24 horas de antecedência e está sujeita a uma taxa adicional, dependendo da localização."
    },
    {
      question: "Os exames de imagem são realizados no mesmo local?",
      answer: "Sim, a MedLab conta com centros integrados onde são realizados tanto exames laboratoriais quanto exames de imagem (ultrassom, raio-X, densitometria óssea, etc.) em um único local, proporcionando maior comodidade. Algumas unidades oferecem todos os serviços, enquanto outras são especializadas em determinados tipos de exames."
    }
  ];

  return (
    <section className="py-16 bg-white relative overflow-hidden">
      {/* Elementos decorativos */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-medlab-yellow opacity-10 rounded-bl-full"></div>
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-red-100 opacity-20 rounded-tr-full"></div>
      
      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1 bg-red-50 rounded-full text-medlab-red text-sm font-medium mb-4">DÚVIDAS FREQUENTES</span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Perguntas Frequentes</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Encontre respostas para as dúvidas mais comuns sobre nossos exames e serviços laboratoriais
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto relative">
          <div className="absolute -left-4 -top-4 w-10 h-10 text-red-100">
            <HelpCircle size={40} strokeWidth={1} />
          </div>
          <div className="absolute -right-4 -bottom-4 w-10 h-10 text-yellow-200">
            <HelpCircle size={40} strokeWidth={1} />
          </div>
          
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`} 
                className="mb-4 border border-gray-200 rounded-lg overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow"
              >
                <AccordionTrigger className="px-6 py-4 text-left font-medium text-gray-800 hover:text-medlab-red hover:no-underline group">
                  <div className="flex items-start">
                    <span className="mr-4 text-medlab-red group-hover:bg-red-50 p-1 rounded-full transition-colors">
                      <ChevronDown className="h-5 w-5 shrink-0 transition-transform duration-200" />
                    </span>
                    <span>{faq.question}</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 py-4 text-gray-600 bg-gray-50 border-t border-gray-200">
                  <div className="pl-10">
                    {faq.answer}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
        
        <div className="text-center mt-16 pt-8 border-t border-gray-100">
          <div className="flex flex-col md:flex-row justify-center items-center gap-6">
            <div className="text-gray-700 flex items-center">
              <MessagesSquare className="mr-2 h-5 w-5 text-medlab-red" />
              <span>Não encontrou o que procurava?</span>
            </div>
            <Button 
              onClick={() => scrollToSection('contato')}
              className="bg-white text-medlab-red border border-red-200 hover:bg-red-50 shadow-sm"
            >
              Fale com nosso atendimento <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
