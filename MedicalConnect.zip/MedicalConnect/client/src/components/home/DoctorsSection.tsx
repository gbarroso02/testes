import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronRight, TestTube, Microscope, Dna, BookOpen } from "lucide-react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";

export default function DoctorsSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const specialists = [
    {
      image: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=400&q=80",
      name: "Dra. Ana Carolina Silva",
      specialty: "Bioquímica",
      icon: <TestTube className="h-5 w-5" />,
      info: "CRBM: 12345 | Experiência: 10 anos",
      specialties: ["Exames de Sangue", "Bioquímica Clínica"]
    },
    {
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=400&q=80",
      name: "Dra. Mariana Ribeiro",
      specialty: "Patologista Clínica",
      icon: <Microscope className="h-5 w-5" />,
      info: "CRM: 45678 | Experiência: 12 anos",
      specialties: ["Citologia", "Patologia"]
    },
    {
      image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=400&q=80",
      name: "Dr. Ricardo Mendes",
      specialty: "Geneticista Molecular",
      icon: <Dna className="h-5 w-5" />,
      info: "CRM: 54321 | Experiência: 15 anos",
      specialties: ["Testes Genéticos", "Biologia Molecular"]
    },
    {
      image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=400&q=80",
      name: "Dr. Pedro Teixeira",
      specialty: "Farmacêutico-Bioquímico",
      icon: <BookOpen className="h-5 w-5" />,
      info: "CRF: 24680 | Experiência: 8 anos",
      specialties: ["Toxicologia", "Farmacologia"]
    }
  ];

  return (
    <section id="medicos" className="py-16 bg-white relative">
      {/* Decoração estilizada nas cores da MedLab */}
      <div className="absolute right-0 top-0 h-24 w-24 bg-red-100 rounded-bl-full opacity-60"></div>
      <div className="absolute right-12 top-12 h-12 w-12 bg-yellow-200 rounded-full opacity-40"></div>
      
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1 bg-red-50 rounded-full text-medlab-red text-sm font-medium mb-4">EQUIPE PROFISSIONAL</span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Especialistas em Laboratório</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Conheça a nossa equipe de especialistas altamente qualificados, que garantem a precisão 
            e confiabilidade de todos os exames realizados na MedLab.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {specialists.map((specialist, index) => (
            <Card key={index} className="bg-white border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition group">
              <div className="relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-10"></div>
                <img 
                  src={specialist.image} 
                  alt={specialist.name} 
                  className="w-full h-64 object-cover transform group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute bottom-0 left-0 right-0 p-4 text-white z-20">
                  <div className="flex items-center mb-1">
                    <div className="bg-white/20 p-1.5 rounded-full mr-2">
                      {specialist.icon}
                    </div>
                    <p className="font-medium">{specialist.specialty}</p>
                  </div>
                </div>
              </div>
              <CardContent className="p-5">
                <h3 className="text-lg font-bold text-gray-800">{specialist.name}</h3>
                <p className="text-gray-500 text-sm mb-3">{specialist.info}</p>
                
                <div className="flex flex-wrap gap-1 mb-4">
                  {specialist.specialties.map((item, i) => (
                    <Badge key={i} variant="outline" className="bg-red-50 text-medlab-red border-red-100">
                      {item}
                    </Badge>
                  ))}
                </div>
                
                <Link href="/agendar/exames">
                  <Button 
                    className="w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600"
                  >
                    Agendar Exames
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <Link href="/especialistas">
            <button className="text-medlab-red font-medium px-8 py-3 rounded-full inline-flex items-center hover:bg-red-50 transition-colors border border-red-100">
              Conhecer toda a equipe <ChevronRight className="ml-2 h-4 w-4" />
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
}
