import { TestTube, UserCheck, Building, Award } from "lucide-react";

export default function StatsSection() {
  const stats = [
    { 
      value: "500K+", 
      label: "Exames Realizados", 
      icon: <TestTube className="h-6 w-6 text-medlab-red" />
    },
    { 
      value: "50+", 
      label: "Tipos de Exames", 
      icon: <Award className="h-6 w-6 text-medlab-red" />
    },
    { 
      value: "15+", 
      label: "Unidades", 
      icon: <Building className="h-6 w-6 text-medlab-red" />
    },
    { 
      value: "98%", 
      label: "Pacientes Satisfeitos", 
      icon: <UserCheck className="h-6 w-6 text-medlab-red" />
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-r from-red-600 to-red-500 text-white relative">
      {/* Elementos decorativos */}
      <div className="absolute top-0 left-0 w-full h-full bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIwOS0xLjc5MS00LTQtNHMtNCAxLjc5MS00IDQgMS43OTEgNCA0IDQgNC0xLjc5MSA0LTR6Ij48L3BhdGg+PC9nPjwvZz48L3N2Zz4=')] opacity-10"></div>
      
      <div className="container mx-auto px-4 relative">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
          {stats.map((stat, index) => (
            <div 
              className="p-6 rounded-lg bg-white bg-opacity-10 backdrop-blur-sm border border-white border-opacity-20 hover:bg-opacity-20 transition-all" 
              key={index}
            >
              <div className="mx-auto mb-4 bg-white bg-opacity-20 w-16 h-16 rounded-full flex items-center justify-center">
                {stat.icon}
              </div>
              <div className="text-white text-4xl font-bold mb-2 drop-shadow-sm">{stat.value}</div>
              <div className="text-white text-opacity-90 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 max-w-4xl mx-auto text-center">
          <h3 className="text-xl md:text-2xl font-medium">
            Com mais de 20 anos de excelência e atuação no mercado, somos referência em exames laboratoriais de alta precisão e confiabilidade.
          </h3>
        </div>
      </div>
    </section>
  );
}
