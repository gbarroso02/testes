import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";

export default function TestimonialsSection() {
  const testimonials = [
    {
      quote: "Excelente atendimento médico! A Dra. Camila foi muito atenciosa e detalhista no diagnóstico. Recomendo a todos que precisam de um cardiologista.",
      author: {
        name: "Mariana Silva",
        since: "Paciente desde 2020",
        avatar: "https://randomuser.me/api/portraits/women/68.jpg"
      },
      rating: 5
    },
    {
      quote: "O atendimento online foi prático e eficiente. O Dr. Ricardo explicou tudo com muita clareza e me passou um tratamento que está funcionando muito bem.",
      author: {
        name: "Carlos Mendes",
        since: "Paciente desde 2021",
        avatar: "https://randomuser.me/api/portraits/men/32.jpg"
      },
      rating: 5
    },
    {
      quote: "Minha filha foi atendida pela Dra. Patrícia e fiquei impressionada com a forma como ela interage com as crianças. Profissional extremamente competente!",
      author: {
        name: "Ana Paula Ferreira",
        since: "Paciente desde 2019",
        avatar: "https://randomuser.me/api/portraits/women/45.jpg"
      },
      rating: 4.5
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">O Que Dizem Nossos Pacientes</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">Descubra por que nossos pacientes confiam em nós para seus cuidados médicos.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white p-8">
              <CardContent className="p-0">
                <div className="flex items-center mb-4">
                  <Quote className="text-primary h-6 w-6 mr-4" />
                  <div className="text-yellow-400 flex">
                    {[...Array(Math.floor(testimonial.rating))].map((_, i) => (
                      <Star key={i} className="fill-current h-4 w-4" />
                    ))}
                    {testimonial.rating % 1 !== 0 && (
                      <Star className="fill-current h-4 w-4" />
                    )}
                  </div>
                </div>
                <p className="text-gray-600 mb-6 italic">"{testimonial.quote}"</p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gray-200 rounded-full mr-4 overflow-hidden">
                    <img 
                      src={testimonial.author.avatar} 
                      alt={testimonial.author.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold">{testimonial.author.name}</h4>
                    <p className="text-sm text-gray-500">{testimonial.author.since}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
