import { Button } from "@/components/ui/button";
import { 
  UserRound, 
  Building2, 
  Laptop, 
  Clock 
} from "lucide-react";

export default function AboutSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const features = [
    {
      icon: <UserRound className="text-primary" />,
      title: "Médicos Especialistas",
      description: "Profissionais com ampla experiência e formação."
    },
    {
      icon: <Building2 className="text-primary" />,
      title: "Instalações Modernas",
      description: "Ambientes confortáveis e equipamentos avançados."
    },
    {
      icon: <Laptop className="text-primary" />,
      title: "Telemedicina",
      description: "Consultas online com a mesma qualidade."
    },
    {
      icon: <Clock className="text-primary" />,
      title: "Atendimento Rápido",
      description: "Sem longas esperas para marcar consultas."
    }
  ];

  return (
    <section id="sobre" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center">
          <div className="lg:w-1/2 mb-10 lg:mb-0 lg:pr-12">
            <img 
              src="https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
              alt="Equipe médica da MediCare" 
              className="rounded-lg shadow-lg w-full"
            />
          </div>
          <div className="lg:w-1/2">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Sobre a MediCare</h2>
            <p className="text-gray-600 mb-6">Somos uma clínica médica comprometida em oferecer atendimento de qualidade, com médicos especializados e tecnologia avançada para diagnóstico e tratamento.</p>
            <p className="text-gray-600 mb-6">Fundada em 2010, nossa missão é proporcionar cuidados médicos humanizados, centrados no paciente e baseados nas melhores práticas e evidências científicas.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start">
                  <div className="bg-primary bg-opacity-10 p-3 rounded-full mr-4">
                    {feature.icon}
                  </div>
                  <div>
                    <h3 className="font-bold mb-2">{feature.title}</h3>
                    <p className="text-gray-600 text-sm">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
            <Button onClick={() => scrollToSection('contato')}>
              Fale Conosco
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
