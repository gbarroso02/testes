import { MapPin, Phone, Mail, Clock, CalendarRange, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ContactSection() {
  const contactInfo = [
    {
      icon: <MapPin className="text-white text-xl" />,
      title: "Endereço",
      lines: ["Av. Paulista, 1000 - Bela Vista", "São Paulo - SP, 01310-100"]
    },
    {
      icon: <Phone className="text-white text-xl" />,
      title: "Telefone",
      lines: ["(11) 3456-7890", "0800 123 4567"]
    },
    {
      icon: <Mail className="text-white text-xl" />,
      title: "E-mail",
      lines: ["contato@medlab.com.br", "atendimento@medlab.com.br"]
    }
  ];

  const openingHours = [
    { day: "Segunda a Sexta", hours: "07:00 - 19:00" },
    { day: "Sábados", hours: "07:00 - 13:00" },
    { day: "Domingos e Feriados", hours: "Fechado" }
  ];

  return (
    <section id="contato" className="py-16 bg-gray-50 relative">
      {/* Elemento decorativo */}
      <div className="absolute bottom-0 right-0 w-32 h-32 bg-yellow-200 opacity-20 rounded-tl-full"></div>
      
      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1 bg-red-50 rounded-full text-medlab-red text-sm font-medium mb-4">FALE CONOSCO</span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Entre em Contato</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Estamos à disposição para esclarecer suas dúvidas e auxiliar no agendamento de exames.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          <div className="lg:col-span-2">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {contactInfo.map((info, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                  <div className="bg-gradient-to-r from-red-600 to-red-500 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    {info.icon}
                  </div>
                  <h3 className="text-lg font-bold mb-2 text-gray-800">{info.title}</h3>
                  {info.lines.map((line, i) => (
                    <p key={i} className="text-gray-600">{line}</p>
                  ))}
                </div>
              ))}
            </div>
            
            <div className="bg-white rounded-lg overflow-hidden shadow-sm h-[300px] md:h-[400px]">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.0976951436757!2d-46.655079!3d-23.563353!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59c7f481fd9f%3A0x9982bfde4df54830!2sAv.%20Paulista%2C%201000%20-%20Bela%20Vista%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2001310-100!5e0!3m2!1spt-BR!2sbr!4v1630000000000!5m2!1spt-BR!2sbr" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }}
                allowFullScreen 
                loading="lazy"
                title="Mapa da localização do laboratório MedLab"
              ></iframe>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm p-8 border border-gray-100">
            <div className="flex items-center mb-6">
              <div className="bg-red-50 text-medlab-red p-2 rounded-lg mr-4">
                <Clock className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold text-gray-800">Horário de Atendimento</h3>
            </div>
            
            <div className="space-y-4 mb-8">
              {openingHours.map((item, index) => (
                <div key={index} className="flex justify-between items-center border-b border-gray-100 pb-3">
                  <span className="font-medium text-gray-700">{item.day}</span>
                  <span className="text-gray-600">{item.hours}</span>
                </div>
              ))}
            </div>
            
            <div className="bg-red-50 rounded-lg p-6 mb-6">
              <div className="flex items-center mb-4">
                <CalendarRange className="text-medlab-red mr-3 h-5 w-5" />
                <h4 className="font-medium text-gray-800">Agendamento Online</h4>
              </div>
              <p className="text-gray-600 text-sm mb-4">
                Agende seus exames de forma rápida e simples através da nossa plataforma online.
              </p>
              <Button className="w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600">
                Agendar Exame
              </Button>
            </div>
            
            <div className="flex items-center">
              <MessageSquare className="text-medlab-red mr-3 h-5 w-5" />
              <p className="text-sm text-gray-600">
                Para mais informações, entre em contato pelo telefone ou e-mail.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
