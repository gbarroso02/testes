// This file can be used to store static data for the application
// Currently, most data is directly included in the components,
// but as the application grows, it can be moved here for better organization.

export const servicesList = [
  {
    title: "Cardiologia",
    description: "Diagnóstico e tratamento de doenças do coração e do sistema cardiovascular.",
    icon: "Heart"
  },
  {
    title: "Neurologia",
    description: "Especializada no diagnóstico e tratamento de doenças do sistema nervoso.",
    icon: "Brain"
  },
  {
    title: "Pneumologia",
    description: "Diagnóstico e tratamento de doenças que afetam o sistema respiratório.",
    icon: "Lungs"
  },
  {
    title: "Ortopedia",
    description: "Especializada no diagnóstico e tratamento de problemas do sistema músculo-esquelético.",
    icon: "Bone"
  },
  {
    title: "Pediatria",
    description: "Cuidados médicos para crianças desde o nascimento até a adolescência.",
    icon: "Baby"
  },
  {
    title: "Oftalmologia",
    description: "Especializada no diagnóstico e tratamento de doenças e condições dos olhos.",
    icon: "Eye"
  }
];

export const doctorsList = [
  {
    name: "Dra. Camila Oliveira",
    specialty: "Cardiologista",
    info: "CRM: 45678 | Experiência: 12 anos",
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=400&q=80"
  },
  {
    name: "Dr. Ricardo Santos",
    specialty: "Neurologista",
    info: "CRM: 54321 | Experiência: 15 anos",
    image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=400&q=80"
  },
  {
    name: "Dra. Patrícia Lima",
    specialty: "Pediatra",
    info: "CRM: 35791 | Experiência: 10 anos",
    image: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=400&q=80"
  },
  {
    name: "Dr. André Martins",
    specialty: "Ortopedista",
    info: "CRM: 24680 | Experiência: 8 anos",
    image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=400&q=80"
  }
];

export const specialties = [
  "cardiologia",
  "neurologia",
  "pediatria",
  "ortopedia",
  "oftalmologia",
  "pneumologia"
];

export const faqList = [
  {
    question: "Como funciona a consulta online?",
    answer: "A consulta online é realizada por videochamada através de nossa plataforma segura. Você receberá um link por e-mail antes da consulta. Basta acessar no horário marcado, e o médico estará disponível para atendê-lo. É necessário ter uma conexão estável com a internet e um dispositivo com câmera e microfone (computador, tablet ou smartphone)."
  },
  {
    question: "Quais convênios são aceitos?",
    answer: "Aceitamos os principais convênios médicos, incluindo Amil, Bradesco Saúde, SulAmérica, Unimed, Porto Seguro, entre outros. Para verificar se seu convênio está na lista de parceiros, entre em contato com nosso atendimento por telefone ou e-mail."
  },
  {
    question: "Como remarcar ou cancelar uma consulta?",
    answer: "Para remarcar ou cancelar uma consulta, acesse sua área do paciente em nosso site ou aplicativo, ou entre em contato com nossa central de atendimento. É importante fazer isso com pelo menos 24 horas de antecedência para evitar possíveis taxas de cancelamento tardio."
  },
  {
    question: "Posso receber receitas médicas pela consulta online?",
    answer: "Sim, nossos médicos podem emitir receitas médicas digitais durante as consultas online. A receita será enviada para seu e-mail ou disponibilizada em sua área do paciente, com assinatura digital válida em todo o território nacional, conforme regulamentações do CFM."
  },
  {
    question: "Qual o valor da consulta particular?",
    answer: "Os valores das consultas particulares variam de acordo com a especialidade médica e o profissional escolhido. Ao agendar pela nossa plataforma, você poderá visualizar o valor exato antes de confirmar. Oferecemos também pacotes de consultas com preços especiais e opções de pagamento parcelado."
  }
];
